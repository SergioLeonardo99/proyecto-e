<template lang="">
    <p>esto es otra prueba</p>
</template>
<script>
export default {
    name:"NotFound"
}
</script>
<style lang="">
    
</style>
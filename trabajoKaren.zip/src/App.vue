<template>
  <!-- cambiar color de fondo -->
  
  <router-view></router-view>


</template>

<!-- <script>

import Navbar from './components/views/elementos/navbar.vue'
export default {
  name: 'App',
  components: {
    // agregar a la compilacion 
    //inicio,
    // InicioPrincipal,
    Navbar
  },
   data() {
        return {
            isActive: true,
            currentPath: window.location.hash
        }
    },
    // computed: {
    //     currentView() {
    //         return routes[this.currentPath.slice(1) || '/'] || NotFound
    //     }
    // },
//     mounted() {
//         window.addEventListener('hashchange', () => {
//             this.currentPath = window.location.hash
//         })
//     },

};
</script>  -->
<style>

*{
    font-family: sans-serif;
}


</style>


//Exportar plugins 

module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
}
